camgaze.js
==========

An implementation of eye tracking in visible light using JavaScript

####Camgaze.js Website
* http://aw204.host.cs.st-andrews.ac.uk/camgaze.js
